# Changes since PA03

- Changed SimulatedPlayer to AiPlayer
- Took in command line arguments for host and port
- Added Client and Proxy pattern to enable talking to the sevrer
- Added JSON functionality and handling server input/output
- Made CommandLineView take in a name for the player