package cs3500.pa04.json;

/**
 * represents a empty json that is used to give no arguments
 */
public record EmptyJson() {
}
